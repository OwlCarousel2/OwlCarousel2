import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listahoteles',
  templateUrl: './listahoteles.component.html',
  styleUrls: ['./listahoteles.component.css']
})
export class ListahotelesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
